import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Owner
global.owner = [
['082136831784', 'Julyo-Putra', true],
]
global.mods = []
global.prems = []
// Info
global.nomorwa = '082136831784'
global.packname = '© Sticker by'
global.author = 'Julyo-Putra'
global.namebot = 'JxL bot'
global.wm = '© JULYO PTRA'
global.stickpack = '© JxL-BOT'
global.stickauth = 'JULYO PTRA'
global.fotonya = 'https://aemt.me/file/2YMdsOwiE2jV.jpg'
global.fotonya2 = `https://aemt.me/file/1zJzovDRFsvB.jpg`
// Link Sosmed
global.sig = 'https://www.instagram.com/_julyours?igsh=MXhzbmc3eGI1MWFlYg=='
global.syt = 'https://youtube.com/@julyoputra1917?si=0oCguZRycTwNPrGG'
global.sgh = 'https://github.com/Julyoputra'
global.sgc = '-'
// Donasi

global.psaweria = '-'
global.ptrakterr = '-'
global.povo = '082148364894'
// Info Wait
global.wait = 'Loading mohon di tunggu ya Cukg...'
global.eror = 'Terjadi Kesalahan Coba Lagi Nanti!'
global.multiplier = 69 
// Apikey
global.lol = 'SGWN'
global.rose = 'Rs-putangina'
global.xyro = '5dRkJDWvIG'
// Catatan : Jika Mau Work Fiturnya
// Masukan Apikeymu
// Gapunya Apikey? Ya Daftar
// Website: https://api.xyroinee.xyz
// Daftar Ke Website Tersebut Untuk
// Mendapatkan Apikey Kamu
global.APIs = {
    xyro: "https://api.xyroinee.xyz",
    popcat : 'https://api.popcat.xyz'
}
/*Apikey*/
global.APIKeys = {
    "https://api.xyroinee.xyz": "5dRkJDWvIG",
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
